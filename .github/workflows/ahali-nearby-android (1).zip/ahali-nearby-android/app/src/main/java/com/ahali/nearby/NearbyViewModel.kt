package com.ahali.nearby

import android.app.Application
import android.content.Context
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.ahali.nearby.nearby.NearbyManager

class NearbyViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("ahali_nearby", Context.MODE_PRIVATE)

    val manager = NearbyManager(app.applicationContext)

    var name by mutableStateOf(prefs.getString(KEY_NAME, null) ?: Build.MODEL)
        private set

    fun updateName(value: String) {
        name = value
        prefs.edit().putString(KEY_NAME, value).apply()
    }

    override fun onCleared() {
        manager.stop()
    }

    private companion object {
        const val KEY_NAME = "name"
    }
}
