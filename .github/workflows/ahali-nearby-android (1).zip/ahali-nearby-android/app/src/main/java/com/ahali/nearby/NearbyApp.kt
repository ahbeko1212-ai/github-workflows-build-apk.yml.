package com.ahali.nearby

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ahali.nearby.nearby.ChatMessage
import com.ahali.nearby.nearby.Peer
import com.ahali.nearby.nearby.PeerStatus

/** Runtime permissions Nearby Connections needs on this Android version. */
private fun requiredPermissions(): Array<String> = when {
    Build.VERSION.SDK_INT >= 33 -> arrayOf(
        Manifest.permission.BLUETOOTH_ADVERTISE,
        Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.BLUETOOTH_SCAN,
        Manifest.permission.NEARBY_WIFI_DEVICES
    )
    Build.VERSION.SDK_INT == 32 -> arrayOf(
        Manifest.permission.BLUETOOTH_ADVERTISE,
        Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.BLUETOOTH_SCAN
    )
    Build.VERSION.SDK_INT == 31 -> arrayOf(
        Manifest.permission.BLUETOOTH_ADVERTISE,
        Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.BLUETOOTH_SCAN,
        Manifest.permission.ACCESS_FINE_LOCATION
    )
    else -> arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NearbyApp(vm: NearbyViewModel = viewModel()) {
    val context = LocalContext.current
    val manager = vm.manager

    val running by manager.running.collectAsState()
    val peers by manager.peers.collectAsState()
    val messages by manager.messages.collectAsState()
    val pending by manager.pending.collectAsState()
    val error by manager.error.collectAsState()

    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(error) {
        error?.let {
            snackbar.showSnackbar(it)
            manager.clearError()
        }
    }

    val needed = remember { requiredPermissions() }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.all { it }) {
            manager.start(vm.name)
        } else {
            manager.postError(context.getString(R.string.permissions_needed))
        }
    }

    fun startWithPermissions() {
        val allGranted = needed.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
        if (allGranted) manager.start(vm.name) else permissionLauncher.launch(needed)
    }

    // Incoming connection request: show the code so both users can compare it.
    pending.firstOrNull()?.let { request ->
        AlertDialog(
            onDismissRequest = { manager.reject(request.id) },
            title = { Text(stringResource(R.string.connection_request, request.name)) },
            text = { Text(stringResource(R.string.confirm_code, request.digits)) },
            confirmButton = {
                TextButton(onClick = { manager.accept(request.id) }) {
                    Text(stringResource(R.string.accept))
                }
            },
            dismissButton = {
                TextButton(onClick = { manager.reject(request.id) }) {
                    Text(stringResource(R.string.reject))
                }
            }
        )
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.app_name)) }) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { inner ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
                .imePadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!running) {
                StartPane(
                    name = vm.name,
                    onNameChange = vm::updateName,
                    onStart = ::startWithPermissions
                )
            } else {
                ChatPane(
                    myName = vm.name,
                    peers = peers.values.sortedBy { it.name },
                    messages = messages,
                    onConnect = manager::requestConnection,
                    onSend = manager::sendText,
                    onStop = manager::stop
                )
            }
        }
    }
}

@Composable
private fun StartPane(name: String, onNameChange: (String) -> Unit, onStart: () -> Unit) {
    Text(
        text = stringResource(R.string.offline_note),
        style = MaterialTheme.typography.bodyMedium
    )
    OutlinedTextField(
        value = name,
        onValueChange = onNameChange,
        label = { Text(stringResource(R.string.your_name)) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
    Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.start))
    }
}

@Composable
private fun androidx.compose.foundation.layout.ColumnScope.ChatPane(
    myName: String,
    peers: List<Peer>,
    messages: List<ChatMessage>,
    onConnect: (String) -> Unit,
    onSend: (String) -> Unit,
    onStop: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = stringResource(R.string.running_as, myName),
            style = MaterialTheme.typography.titleSmall
        )
        OutlinedButton(onClick = onStop) { Text(stringResource(R.string.stop)) }
    }

    Text(
        text = stringResource(R.string.nearby_devices),
        style = MaterialTheme.typography.titleMedium
    )

    if (peers.isEmpty()) {
        Text(
            text = stringResource(R.string.searching),
            style = MaterialTheme.typography.bodyMedium
        )
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.35f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(peers, key = { it.id }) { peer -> PeerRow(peer, onConnect) }
        }
    }

    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }
    LazyColumn(
        state = listState,
        modifier = Modifier
            .fillMaxWidth()
            .weight(0.65f),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items(messages) { message -> MessageBubble(message) }
    }

    var draft by remember { mutableStateOf("") }
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedTextField(
            value = draft,
            onValueChange = { draft = it },
            placeholder = { Text(stringResource(R.string.message_hint)) },
            modifier = Modifier.weight(1f)
        )
        Button(onClick = {
            onSend(draft)
            draft = ""
        }) {
            Text(stringResource(R.string.send))
        }
    }
}

@Composable
private fun PeerRow(peer: Peer, onConnect: (String) -> Unit) {
    Surface(
        tonalElevation = 2.dp,
        shape = MaterialTheme.shapes.medium,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = peer.name,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f)
            )
            when (peer.status) {
                PeerStatus.DISCOVERED -> Button(onClick = { onConnect(peer.id) }) {
                    Text(stringResource(R.string.connect))
                }
                PeerStatus.CONNECTING -> Text(stringResource(R.string.connecting))
                PeerStatus.CONNECTED -> Text(
                    text = stringResource(R.string.connected),
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (message.fromMe) Alignment.End else Alignment.Start
    ) {
        Surface(
            color = if (message.fromMe) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            },
            shape = MaterialTheme.shapes.medium
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                if (!message.fromMe) {
                    Text(
                        text = message.senderName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Text(text = message.text, style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}
