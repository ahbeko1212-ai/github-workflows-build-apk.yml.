package com.ahali.nearby.nearby

import android.content.Context
import com.ahali.nearby.R
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONObject

enum class PeerStatus { DISCOVERED, CONNECTING, CONNECTED }

data class Peer(val id: String, val name: String, val status: PeerStatus)

data class IncomingRequest(val id: String, val name: String, val digits: String)

data class ChatMessage(
    val fromMe: Boolean,
    val senderName: String,
    val text: String,
    val time: Long = System.currentTimeMillis()
)

/**
 * Wraps Google Nearby Connections (Bluetooth + Wi-Fi Direct, no internet needed).
 * All callbacks arrive on the main thread, so plain StateFlow updates are safe.
 */
class NearbyManager(private val context: Context) {

    private val client: ConnectionsClient = Nearby.getConnectionsClient(context)

    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    private val _peers = MutableStateFlow<Map<String, Peer>>(emptyMap())
    val peers: StateFlow<Map<String, Peer>> = _peers.asStateFlow()

    private val _pending = MutableStateFlow<List<IncomingRequest>>(emptyList())
    val pending: StateFlow<List<IncomingRequest>> = _pending.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val outgoing = mutableSetOf<String>()
    private var myName = ""

    // ---------- Public API ----------

    fun start(name: String) {
        if (_running.value) return
        myName = name.trim().ifEmpty { "Ahali" }

        val advertisingOptions = AdvertisingOptions.Builder().setStrategy(STRATEGY).build()
        client.startAdvertising(myName, SERVICE_ID, lifecycleCallback, advertisingOptions)
            .addOnFailureListener { postError(it.message ?: "Advertising failed") }

        val discoveryOptions = DiscoveryOptions.Builder().setStrategy(STRATEGY).build()
        client.startDiscovery(SERVICE_ID, discoveryCallback, discoveryOptions)
            .addOnFailureListener { postError(it.message ?: "Discovery failed") }

        _running.value = true
    }

    fun stop() {
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
        outgoing.clear()
        _peers.value = emptyMap()
        _pending.value = emptyList()
        _running.value = false
    }

    fun requestConnection(id: String) {
        outgoing.add(id)
        setStatus(id, PeerStatus.CONNECTING)
        client.requestConnection(myName, id, lifecycleCallback)
            .addOnFailureListener {
                outgoing.remove(id)
                setStatus(id, PeerStatus.DISCOVERED)
                postError(it.message ?: "Connection request failed")
            }
    }

    fun accept(id: String) {
        client.acceptConnection(id, payloadCallback)
            .addOnFailureListener { postError(it.message ?: "Accept failed") }
        _pending.update { list -> list.filterNot { it.id == id } }
        setStatus(id, PeerStatus.CONNECTING)
    }

    fun reject(id: String) {
        client.rejectConnection(id)
        _pending.update { list -> list.filterNot { it.id == id } }
    }

    fun sendText(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return

        val targets = _peers.value.values
            .filter { it.status == PeerStatus.CONNECTED }
            .map { it.id }
        if (targets.isEmpty()) {
            postError(context.getString(R.string.no_peers_connected))
            return
        }

        val json = JSONObject().put("n", myName).put("x", clean).toString()
        client.sendPayload(targets, Payload.fromBytes(json.toByteArray(Charsets.UTF_8)))
            .addOnFailureListener { postError(it.message ?: "Send failed") }

        _messages.update { it + ChatMessage(true, myName, clean) }
    }

    fun postError(message: String) {
        _error.value = message
    }

    fun clearError() {
        _error.value = null
    }

    // ---------- Internals ----------

    private fun setStatus(id: String, status: PeerStatus) {
        _peers.update { map ->
            val peer = map[id] ?: return@update map
            map + (id to peer.copy(status = status))
        }
    }

    private val discoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            _peers.update { map ->
                val old = map[id]
                map + (id to Peer(id, info.endpointName, old?.status ?: PeerStatus.DISCOVERED))
            }
        }

        override fun onEndpointLost(id: String) {
            _peers.update { map ->
                val peer = map[id]
                if (peer != null && peer.status == PeerStatus.DISCOVERED) map - id else map
            }
        }
    }

    private val lifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            _peers.update { map ->
                map + (id to Peer(id, info.endpointName, PeerStatus.CONNECTING))
            }
            if (outgoing.contains(id)) {
                // We asked for this connection, so accept automatically.
                client.acceptConnection(id, payloadCallback)
                    .addOnFailureListener { postError(it.message ?: "Accept failed") }
            } else {
                // Incoming request: let the user compare the code and decide.
                _pending.update { list ->
                    list + IncomingRequest(id, info.endpointName, info.authenticationDigits)
                }
            }
        }

        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            val ok = result.status.statusCode == ConnectionsStatusCodes.STATUS_OK
            outgoing.remove(id)
            _pending.update { list -> list.filterNot { it.id == id } }
            setStatus(id, if (ok) PeerStatus.CONNECTED else PeerStatus.DISCOVERED)
        }

        override fun onDisconnected(id: String) {
            setStatus(id, PeerStatus.DISCOVERED)
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, payload: Payload) {
            if (payload.type != Payload.Type.BYTES) return
            val bytes = payload.asBytes() ?: return
            runCatching {
                val json = JSONObject(String(bytes, Charsets.UTF_8))
                val sender = json.optString("n", _peers.value[id]?.name ?: "?")
                val text = json.getString("x")
                _messages.update { it + ChatMessage(false, sender, text) }
            }
        }

        override fun onPayloadTransferUpdate(id: String, update: PayloadTransferUpdate) {
            // Needed later for files and photos (progress). Text messages arrive in one piece.
        }
    }

    companion object {
        private const val SERVICE_ID = "com.ahali.nearby.SERVICE"
        private val STRATEGY = Strategy.P2P_CLUSTER
    }
}
